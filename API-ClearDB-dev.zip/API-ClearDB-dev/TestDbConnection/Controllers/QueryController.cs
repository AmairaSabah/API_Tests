﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics.Metrics;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TestDbConnection.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QueryController : ControllerBase
    {
        const string select = "select";
        private IConfiguration _configuration;
        public QueryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpPost]
        [Route("Execute")]
        public async Task<ActionResult> PostAsync([FromBody] string query)
        {
            try
            {
                if (string.IsNullOrEmpty(query)) { return BadRequest("Empty query"); }
                string connectionString;
                connectionString = Environment.GetEnvironmentVariable("DB_ConnectionString");
                if (string.IsNullOrEmpty(connectionString))
                {
                    connectionString = _configuration["Data:ConnectionString"];
                }
                if (string.IsNullOrEmpty(connectionString))
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "database connection string not found");
                }

                using var connection = new SqlConnection(connectionString);
                using var command = new SqlCommand(query, connection);
                try
                {
                    await connection.OpenAsync();
                    List<Dictionary<string, object>> result = new List<Dictionary<string, object>>();
                    if (query.ToLower().Contains(select.ToLower()))
                    {
                        using var reader = await command.ExecuteReaderAsync();

                        if (reader.HasRows)
                        {
                            result = ConvertToList(reader);
                        }
                        await reader.CloseAsync();
                        await connection.CloseAsync();
                        return Ok(result);
                    }
                    else
                    {
                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        await connection.CloseAsync();
                        return Ok($"Rows affected: {rowsAffected}");
                    }

                }
                catch (Exception ex)
                {
                    if (connection.State != ConnectionState.Closed)
                    {
                        await connection.CloseAsync();
                    }
                    return StatusCode(StatusCodes.Status500InternalServerError, $"Exception while executing \"{query}\": {ex.Message}");
                }
            }
            catch(Exception exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"internal server exception: {exception.Message}");
            }
           
        }


        private static List<Dictionary<string, object>> ConvertToList(IDataReader reader)
        {
            var result = new List<Dictionary<string, object>>();

            while (reader.Read())
            {
                var row = new Dictionary<string, object>();

                for (int i = 0; i < reader.FieldCount; i++)
                    row.Add(reader.GetName(i), reader[i]);

                result.Add(row);
            }

            return result;
        }
    }
}
