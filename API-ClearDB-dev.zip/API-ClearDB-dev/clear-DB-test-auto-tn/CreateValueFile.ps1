#!/bin/bash

$envname="sopm-dev"
$content = Get-Content -Path "values.yaml"
$newContent = $content -replace "env-name", $envname


$newContent | Set-Content -Path "values-modfied.yaml"