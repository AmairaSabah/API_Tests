#!/bin/bash

envname=sopm-dev
dockerimageregistry=registry.us.se.com

sed "s/env-name/$envname/g" values.yaml |
sed "s/dockerimageregistry.io/$dockerimageregistry/g" > $envname-values.yaml